#include <ESP8266_SEGMENT_LED_SSD1306_SW_I2C.h>

SEGMENT_SSD1306::SEGMENT_SSD1306(int8_t _SDA_pin, int8_t _SCL_pin) 
{	
	if (_SDA_pin != -1) setSDA((uint8_t)_SDA_pin);
	if (_SCL_pin != -1) setSCL((uint8_t)_SCL_pin);
}

void SEGMENT_SSD1306::setSDA(uint8_t _SDA_pin) { TWI.setSDA(_SDA_pin); }
void SEGMENT_SSD1306::setSCL(uint8_t _SCL_pin) { TWI.setSCL(_SCL_pin); }


void SEGMENT_SSD1306::begin() 
{			
	TWI.startCondition();
	TWI.write(SSD1306_ADDRESS);
	TWI.write(SSD1306_COMMAND_BYTE);
	
    TWI.write(SSD1306_DISPLAYOFF);
    TWI.write(SSD1306_SETDISPLAYCLOCKDIV);
    TWI.write(0x80);
    TWI.write(SSD1306_SETMULTIPLEX);
    TWI.write(0x3F);
    TWI.write(SSD1306_SETDISPLAYOFFSET);
    TWI.write(0x00);
    TWI.write(SSD1306_SETSTARTLINE | 0x00);
    TWI.write(SSD1306_CHARGEPUMP);
    TWI.write(0x14);
    TWI.write(SSD1306_MEMORYMODE);
    TWI.write(0x04);
    TWI.write(SSD1306_SEGREMAP | 0x1);
    TWI.write(SSD1306_COMSCANDEC);
    TWI.write(SSD1306_SETCOMPINS);
    TWI.write(0x12);
    TWI.write(SSD1306_SETCONTRAST);
    TWI.write(0xCF);
    TWI.write(SSD1306_SETPRECHARGE);
    TWI.write(0xF1);
    TWI.write(SSD1306_SETVCOMDETECT);
    TWI.write(0x40);
    TWI.write(SSD1306_DISPLAYALLON_RESUME);
    TWI.write(SSD1306_NORMALDISPLAY);
    TWI.write(SSD1306_DISPLAYON);
	TWI.stopCondition();	
	
	clear();
}

void SEGMENT_SSD1306::showDigit(uint16_t _digit) 
{	
	//uint16_t* addrBuff = 0;
	
	uint8_t byteBuffer_1 = 0;
	uint8_t byteBuffer_2 = 0;
	uint8_t byteBuffer_3 = 0;
	uint8_t byteBuffer_4 = 0;
	
	uint8_t resultByte = 0;
	uint8_t mask = 0x80;
	
	TWI.startCondition();
	TWI.write(SSD1306_ADDRESS);
	TWI.write(SSD1306_DATA_BYTE);

	for (int k = 0; k < 8; k++) 
	{
		for (uint8_t i = 0; i < 16; i++) 
		{
			byteBuffer_1 = pgm_read_dword( DIGITS[_digit] + 16*k*4 + i);
			byteBuffer_2 = pgm_read_dword( DIGITS[_digit] + 16*k*4 + i + 16);
			byteBuffer_3 = pgm_read_dword( DIGITS[_digit] + 16*k*4 + i + 32);
			byteBuffer_4 = pgm_read_dword( DIGITS[_digit] + 16*k*4 + i + 48);
			
			for (uint8_t j = 0; j < 8; j++) 
			{
				if ((byteBuffer_1 & mask) != 0)
					resultByte |= 0b00000010;
				if ((byteBuffer_2 & mask) != 0)
					resultByte |= 0b00001000;
				if ((byteBuffer_3 & mask) != 0)
					resultByte |= 0b00100000;
				if ((byteBuffer_4 & mask) != 0)
					resultByte |= 0b10000000;
				
				TWI.write(resultByte);
				
				mask >>= 1;
				resultByte = 0;
			}
			mask = 0x80;
			resultByte = 0;
		}	
	}
	
	TWI.stopCondition();	
}

void SEGMENT_SSD1306::show_WIFISearch(uint8_t dots) 
{	
	if (dots < 3) 
	{
		uint8_t byteBuffer_1 = 0;
		uint8_t byteBuffer_2 = 0;
		uint8_t byteBuffer_3 = 0;
		uint8_t byteBuffer_4 = 0;
		
		uint8_t resultByte = 0;
		uint8_t mask = 0x80;
		
		TWI.startCondition();
		TWI.write(SSD1306_ADDRESS);
		TWI.write(SSD1306_DATA_BYTE);

		for (int k = 0; k < 8; k++) 
		{
			for (uint8_t i = 0; i < 16; i++) 
			{
				byteBuffer_1 = pgm_read_dword( WIFI_TEXTS[dots] + 16*k*4 + i);
				byteBuffer_2 = pgm_read_dword( WIFI_TEXTS[dots] + 16*k*4 + i + 16);
				byteBuffer_3 = pgm_read_dword( WIFI_TEXTS[dots] + 16*k*4 + i + 32);
				byteBuffer_4 = pgm_read_dword( WIFI_TEXTS[dots] + 16*k*4 + i + 48);
				
				for (uint8_t j = 0; j < 8; j++) 
				{
					if ((byteBuffer_1 & mask) != 0)
						resultByte |= 0b00000010;
					if ((byteBuffer_2 & mask) != 0)
						resultByte |= 0b00001000;
					if ((byteBuffer_3 & mask) != 0)
						resultByte |= 0b00100000;
					if ((byteBuffer_4 & mask) != 0)
						resultByte |= 0b10000000;
					
					TWI.write(resultByte);
					
					mask >>= 1;
					resultByte = 0;
				}
				mask = 0x80;
				resultByte = 0;
			}	
		}
		
		TWI.stopCondition();
	}	
}
	
void SEGMENT_SSD1306::show_F() { LETTER_bitmapSender(0); }
void SEGMENT_SSD1306::show_A() { LETTER_bitmapSender(1); }
void SEGMENT_SSD1306::show_I() { LETTER_bitmapSender(2); }
void SEGMENT_SSD1306::show_L() { LETTER_bitmapSender(3); }


void SEGMENT_SSD1306::LETTER_bitmapSender(uint16_t element) 
{
	uint8_t byteBuffer_1 = 0;
	uint8_t byteBuffer_2 = 0;
	uint8_t byteBuffer_3 = 0;
	uint8_t byteBuffer_4 = 0;
	
	uint8_t resultByte = 0;
	uint8_t mask = 0x80;
	
	TWI.startCondition();
	TWI.write(SSD1306_ADDRESS);
	TWI.write(SSD1306_DATA_BYTE);

	for (int k = 0; k < 8; k++) 
	{
		for (uint8_t i = 0; i < 16; i++) 
		{
			byteBuffer_1 = pgm_read_dword( LETTERS[element] + 16*k*4 + i);
			byteBuffer_2 = pgm_read_dword( LETTERS[element] + 16*k*4 + i + 16);
			byteBuffer_3 = pgm_read_dword( LETTERS[element] + 16*k*4 + i + 32);
			byteBuffer_4 = pgm_read_dword( LETTERS[element] + 16*k*4 + i + 48);
			
			for (uint8_t j = 0; j < 8; j++) 
			{
				if ((byteBuffer_1 & mask) != 0)
					resultByte |= 0b00000010;
				if ((byteBuffer_2 & mask) != 0)
					resultByte |= 0b00001000;
				if ((byteBuffer_3 & mask) != 0)
					resultByte |= 0b00100000;
				if ((byteBuffer_4 & mask) != 0)
					resultByte |= 0b10000000;
				
				TWI.write(resultByte);
				
				mask >>= 1;
				resultByte = 0;
			}
			mask = 0x80;
			resultByte = 0;
		}	
	}
	
	TWI.stopCondition();	
}


void SEGMENT_SSD1306::setToStart() 
{
	TWI.startCondition();
	TWI.write(SSD1306_ADDRESS);
	TWI.write(SSD1306_COMMAND_BYTE);
	
	TWI.write(0x40);
	
	
	TWI.stopCondition();	
}

void SEGMENT_SSD1306::clear() 
{
	TWI.startCondition(SSD1306_ADDRESS);
	TWI.write(SSD1306_DATA_BYTE);
	
	for (int i = 0; i < 1024; i++)
		TWI.write(0x00);
	
	TWI.stopCondition();	
}

// 0xFF - 0b10101010