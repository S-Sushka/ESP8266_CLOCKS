#include <Arduino.h>
#include <SW_I2C.h>
#include <bitmaps.h>

#define SSD1306_ADDRESS 		0b01111000
#define SSD1306_DATA_BYTE 	    0b01000000
#define SSD1306_COMMAND_BYTE    0b00000000

#define SSD1306_SETCONTRAST 0x81
#define SSD1306_DISPLAYALLON_RESUME 0xA4
#define SSD1306_DISPLAYALLON 0xA5
#define SSD1306_NORMALDISPLAY 0xA6
#define SSD1306_INVERTDISPLAY 0xA7
#define SSD1306_DISPLAYOFF 0xAE
#define SSD1306_DISPLAYON 0xAF
#define SSD1306_SETDISPLAYOFFSET 0xD3
#define SSD1306_SETCOMPINS 0xDA
#define SSD1306_SETVCOMDETECT 0xDB
#define SSD1306_SETDISPLAYCLOCKDIV 0xD5
#define SSD1306_SETPRECHARGE 0xD9
#define SSD1306_SETMULTIPLEX 0xA8
#define SSD1306_SETLOWCOLUMN 0x00
#define SSD1306_SETHIGHCOLUMN 0x10
#define SSD1306_SETSTARTLINE 0x40
#define SSD1306_MEMORYMODE 0x20
#define SSD1306_COLUMNADDR 0x21
#define SSD1306_PAGEADDR   0x22
#define SSD1306_COMSCANINC 0xC0
#define SSD1306_COMSCANDEC 0xC8
#define SSD1306_SEGREMAP 0xA0
#define SSD1306_CHARGEPUMP 0x8D
#define SSD1306_SWITCHCAPVCC 0x2
#define SSD1306_NOP 0xE3

#define DIGIT_SIZE 592

#ifndef OLED_H
#define OLED_H

const uint16_t* const PROGMEM WIFI_TEXTS[3] = {&SEARCH_WIFI_1_DOT[0], &SEARCH_WIFI_2_DOT[0], &SEARCH_WIFI_3_DOT[0]};
const uint16_t* const PROGMEM LETTERS[4] = {&LETTER_F[0], &LETTER_A[0], &LETTER_I[0], &LETTER_L[0]};
const uint16_t* const PROGMEM DIGITS[10] = {&DIGIT_0[0], &DIGIT_1[0], &DIGIT_2[0], &DIGIT_3[0], &DIGIT_4[0], &DIGIT_5[0], &DIGIT_6[0], &DIGIT_7[0], &DIGIT_8[0], &DIGIT_9[0]};


class SEGMENT_SSD1306
{	
	SoftWare_I2C TWI = SoftWare_I2C(-1, -1);
	
	void LETTER_bitmapSender(uint16_t element);
	
	void setToStart();
	void clear();
	
public:	
	SEGMENT_SSD1306(int8_t _SDA_pin, int8_t _SCL_pin);	
	void setSDA(uint8_t _SDA_pin);
	void setSCL(uint8_t _SCL_pin);
	
	void begin();
	
	void showDigit(uint16_t digit);
	
	void show_WIFISearch(uint8_t dots);
	
	void show_F();
	void show_A();
	void show_I();
	void show_L();
};

#endif